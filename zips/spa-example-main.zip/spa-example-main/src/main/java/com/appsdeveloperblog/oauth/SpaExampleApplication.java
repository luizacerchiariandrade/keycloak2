package com.appsdeveloperblog.oauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpaExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpaExampleApplication.class, args);
	}

}
