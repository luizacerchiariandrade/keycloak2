package com.appsdeveloperblog.ws.clients;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoAppWebClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
