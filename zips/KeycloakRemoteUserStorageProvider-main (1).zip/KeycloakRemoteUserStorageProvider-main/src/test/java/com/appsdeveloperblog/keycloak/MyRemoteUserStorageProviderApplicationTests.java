package com.appsdeveloperblog.keycloak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyRemoteUserStorageProviderApplicationTests {

	@Test
	void contextLoads() {
	}

}
