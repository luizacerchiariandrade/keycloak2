package com.appsdeveloperblog.clients.sociallogin.SocialLoginWebClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialLoginWebClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialLoginWebClientApplication.class, args);
	}

}
