package com.appsdeveloperblog.clients.sociallogin.SocialLoginWebClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialLoginWebClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
